const mongoose = require('mongoose');

// Define the Group schema and model
const GroupSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true, trim: true },
    description: { type: String, required: true, trim: true },
    createdAt: { type: Date, default: Date.now }
});
const Group = mongoose.model('Group', GroupSchema);

// Connect to MongoDB and seed the database
mongoose.connect('mongodb://127.0.0.1:27017/simple-reddit', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(async () => {
    console.log('Connected to MongoDB');

    // Clear existing groups (optional)
    await Group.deleteMany({});

    // Insert test data
    await Group.insertMany([
        { name: "Test Group 1", description: "This is a test group" },
        { name: "Test Group 2", description: "Another test group" }
    ]);

    console.log('Test data inserted');
    mongoose.connection.close();
})
.catch(err => {
    console.error('Error connecting to MongoDB:', err);
});