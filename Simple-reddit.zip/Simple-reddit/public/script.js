// script.js (UPDATED: Includes Group list loading, selection, and post filtering)
document.addEventListener('DOMContentLoaded', function() {

    // --- DOM Element Selectors ---
    const postForm = document.querySelector('#post-form'); // Assuming you added id="post-form" to your submit post form
    const postListContainer = document.getElementById('post-list-container'); // Target the new container for posts
    const postListTitle = document.querySelector('.post-list h2'); // Target the H2 above the post list
    const titleInput = document.getElementById('post-title');
    const contentInput = document.getElementById('post-content');

    const registrationForm = document.getElementById('registration-form');
    const registrationMessage = document.querySelector('.registration-message');

    const loginForm = document.getElementById('login-form');
    const loginMessage = document.querySelector('.login-message');

    const groupListElement = document.getElementById('group-list'); // Target the UL for groups

    // --- State Variable ---
    let selectedGroupId = 'all'; // Track the currently selected group ('all' or an ObjectId)

    // --- Helper function to render a single post ---
    // --- MODIFIED: Added isAllFeed param and logic to show group name ---
    function renderPost(post, isAllFeed = false) { // Default isAllFeed to false
        const newPost = document.createElement('div');
        newPost.classList.add('post');
        newPost.dataset.postId = post._id; // Store post ID

        // Build author/group info string
        let authorHtml = `Posted on ${new Date(post.createdAt).toLocaleDateString()}`;
        if (post.author && post.author.username) {
            authorHtml += ` by ${post.author.username}`;
        } else {
             authorHtml += ` by Unknown Author`; // Fallback
        }
        // Add group name IF on the 'all' feed and group info exists
        if (isAllFeed && post.group && post.group.name) {
            // Maybe make the group name a link later? For now, just text.
            authorHtml += ` in <span class="post-group-name">${post.group.name}</span>`;
        }

        newPost.innerHTML = `
            <div class="post-header">
                <h3><a href="#">${post.title}</a></h3>
                <p class="author">${authorHtml}</p> </div>
            <div class="post-content">
                <p>${post.content}</p>
            </div>
            <div class="post-actions">
                <div class="votes">
                    <button class="upvote" data-post-id="${post._id}">▲</button>
                    <span class="vote-count" data-post-id="${post._id}">${post.votes}</span>
                    <button class="downvote" data-post-id="${post._id}">▼</button>
                </div>
                 <a href="#" class="comments-link" data-post-id="${post._id}">Comments (0)</a>
            </div>
            <div class="comment-section">
                <h4>Add a Comment</h4>
                <textarea class="comment-input" data-post-id="${post._id}" placeholder="Your comment"></textarea>
                <button class="submit-comment" data-post-id="${post._id}">Submit</button>
            </div>
            <div class="comments-list" data-post-id="${post._id}">
                </div>
        `;
        return newPost; // Return the created element
    }

    // --- Helper function to render comments for a specific post ---
    // --- MODIFIED: Use comment.author.username (already done) ---
    function renderComments(postId, comments) {
        const commentsList = document.querySelector(`.comments-list[data-post-id="${postId}"]`);
        const commentsLink = document.querySelector(`.comments-link[data-post-id="${postId}"]`);

        if (!commentsList) return;

        commentsList.innerHTML = ''; // Clear previous comments
        if (comments && comments.length > 0) {
            comments.forEach(comment => {
                const commentElement = document.createElement('div');
                commentElement.classList.add('comment');
                const authorName = comment.author ? comment.author.username : 'Unknown Author';
                commentElement.innerHTML = `
                    <p class="comment-author">${authorName}:</p>
                    <p class="comment-text">${comment.text}</p>
                    <p class="comment-date">${new Date(comment.createdAt).toLocaleDateString()}</p>
                `;
                commentsList.appendChild(commentElement);
            });
        } else {
             commentsList.innerHTML = '<p>No comments yet.</p>'; // Message if no comments
        }


        // Update the comments link text
        if (commentsLink) {
            commentsLink.textContent = `Comments (${comments ? comments.length : 0})`;
        }
    }

    // --- Helper function to fetch and render comments for a post ---
    function fetchAndRenderComments(postId) {
        fetch(`/api/posts/${postId}/comments`)
            .then(response => {
                if (!response.ok) {
                    // Don't throw error here, just log it maybe, or display in commentsList
                    console.error(`HTTP error fetching comments! status: ${response.status}`);
                    return []; // Return empty array on error
                }
                return response.json();
            })
            .then(comments => {
                renderComments(postId, comments);
            })
            .catch(error => {
                console.error(`Error fetching comments for post ${postId}:`, error);
                const commentsList = document.querySelector(`.comments-list[data-post-id="${postId}"]`);
                if (commentsList) commentsList.innerHTML = '<p class="error-message">Could not load comments.</p>';
                renderComments(postId, []); // Render with empty array state
            });
    }

    // --- NEW FUNCTION: Fetch and Render Groups ---
    // --- MODIFIED: Added data-group-name ---
    function fetchAndRenderGroups() {
        if (!groupListElement) return; // Don't run if the element doesn't exist
    
        // Update the URL to include the correct port
        fetch('/api/groups')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch groups');
                return response.json();
            })
            .then(groups => {
                // Clear existing groups except the 'All Posts' one if needed
                groups.forEach(group => {
                    const li = document.createElement('li');
                    const link = document.createElement('a');
                    link.href = '#';
                    link.textContent = group.name;
                    link.dataset.groupId = group._id; // Store ID
                    link.dataset.groupName = group.name; // <<<--- Store Name
                    link.classList.add('group-link'); // Class for listener
                    li.appendChild(link);
                    groupListElement.appendChild(li);
                });
            })
            .catch(error => {
                console.error('Error fetching groups:', error);
                groupListElement.innerHTML += '<li>Error loading groups</li>';
            });
    }
    

    // --- MODIFIED fetchPosts function ---
    // Accepts groupId and groupName, targets correct container, passes isAllFeed flag
    function fetchPosts(groupId = 'all', groupName = 'All Posts') {
         let url = '/api/posts'; // Default to 'all' feed API
         let title = 'Recent Posts (All)'; // Default title

         if (groupId !== 'all') {
             url = `/api/groups/${groupId}/posts`; // Group-specific API
             title = `Posts in ${groupName}`; // Use group name in title
         }
         console.log(`Workspaceing posts from: ${url}`); // Debugging

         // Clear previous posts immediately for better UX
         if(postListContainer) postListContainer.innerHTML = '<p>Loading posts...</p>';
         if(postListTitle) postListTitle.textContent = title; // Update title

         fetch(url)
            .then(response => {
                 if (!response.ok) {
                    // Provide more specific error info if possible
                    return response.json().then(err => {
                        throw new Error(err.error || `HTTP error! status: ${response.status}`);
                    });
                 }
                 return response.json();
            })
            .then(posts => {
                if(!postListContainer) return; // Should not happen if HTML is correct

                postListContainer.innerHTML = ''; // Clear loading message

                if (!posts || posts.length === 0) {
                    postListContainer.innerHTML = '<p>No posts found in this group.</p>';
                    return;
                }

                posts.forEach(post => {
                    // Pass true to isAllFeed only if groupId is 'all'
                    const postElement = renderPost(post, groupId === 'all');
                    // Use append instead of prepend to maintain sorted order (newest first from API)
                    postListContainer.appendChild(postElement);
                    // Fetch comments for each rendered post
                    fetchAndRenderComments(post._id);
                });
            })
            .catch(error => {
                console.error('Error fetching posts:', error);
                 if(postListContainer) postListContainer.innerHTML = `<p class="error-message">Failed to load posts: ${error.message}</p>`;
                if(postListTitle) postListTitle.textContent = 'Error Loading Posts';
            });
    }

    // --- EVENT LISTENER FOR GROUP SELECTION ---
    // --- NEW: Handles clicks in the sidebar ---
    if (groupListElement) {
        groupListElement.addEventListener('click', (event) => {
            if (event.target.tagName === 'A') {
                event.preventDefault();

                let newGroupId = 'all';
                let newGroupName = 'All Posts';

                if (event.target.classList.contains('group-link')) {
                    newGroupId = event.target.dataset.groupId;
                    newGroupName = event.target.dataset.groupName;
                } else if (event.target.id !== 'all-posts-link') {
                   return; // Ignore clicks not on group links or the 'all' link
                }

                // Only refetch if the selection actually changed
                if (newGroupId !== selectedGroupId) {
                    selectedGroupId = newGroupId;
                    console.log(`Selected group: ${selectedGroupId} (${newGroupName})`);

                    // Update highlighting
                    const currentActive = groupListElement.querySelector('.active-group');
                    if (currentActive) {
                        currentActive.classList.remove('active-group');
                    }
                    event.target.classList.add('active-group');

                    // Fetch and render posts for the selected group/all
                    fetchPosts(selectedGroupId, newGroupName);

                    // --- LATER: Update submit form context ---
                    // We'll need to handle how the submit form knows which group is selected
                    // Maybe disable submit form if 'all' is selected?
                    const submitSection = document.querySelector('.submit-post');
                    if (submitSection) {
                        if (selectedGroupId === 'all') {
                             console.log("Viewing all posts - hide/disable submit form?");
                             // Example: submitSection.style.display = 'none';
                        } else {
                             console.log(`Submitting to group ${selectedGroupId}`);
                             // Example: submitSection.style.display = 'block';
                        }
                    }
                }
            }
        });
    }

    // --- Existing Event Listeners (Votes, Submit Comment) ---
    // Using event delegation on document is okay, but could be more specific if needed
    document.addEventListener('click', async function(event) {
        // Handle Upvote
        if (event.target.classList.contains('upvote')) {
            const postId = event.target.dataset.postId;
            await updateVote(postId, 'upvote');
        }
        // Handle Downvote
        else if (event.target.classList.contains('downvote')) {
            const postId = event.target.dataset.postId;
            await updateVote(postId, 'downvote');
        }
        // Handle Submit Comment
        else if (event.target.classList.contains('submit-comment')) {
            const postId = event.target.dataset.postId;
            const commentInput = document.querySelector(`.comment-input[data-post-id="${postId}"]`);
            if (!commentInput) return; // Avoid errors if element not found
            const commentText = commentInput.value.trim();
            const authToken = localStorage.getItem('authToken');

            if (!commentText) {
                alert('Please enter a comment.');
                return;
            }

            if (!authToken) {
                alert('You must be logged in to comment.');
                return;
            }

            try {
                const response = await fetch(`/api/posts/${postId}/comments`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${authToken}`,
                    },
                    body: JSON.stringify({ text: commentText }),
                });

                if (!response.ok) {
                    let error = { message: `HTTP error! status: ${response.status}` };
                    try { error = await response.json(); } catch(e) {}
                    console.error('Error submitting comment:', error);
                    alert(error.error || error.message || 'Failed to submit comment.');
                    return;
                }

                commentInput.value = '';
                fetchAndRenderComments(postId); // Refetch and render comments

            } catch (error) {
                console.error('Network or other error submitting comment:', error);
                alert('Network error while submitting comment.');
            }
        }
    });

    // --- Submit New Post Form Handling ---
    // --- MODIFIED: Needs update for Group context ---
    if (postForm) { // Check if form exists
        postForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const title = titleInput.value.trim();
            const content = contentInput.value.trim();
            const authToken = localStorage.getItem('authToken');

             // --- CHECK WHICH GROUP IS SELECTED ---
             if (selectedGroupId === 'all') {
                 alert('Please select a specific group from the sidebar before submitting a post.');
                 return;
             }
             // --- END CHECK ---

            if (!title || !content) {
                alert('Please enter both title and content.');
                return;
            }
            if (!authToken) {
                alert('You must be logged in to submit a post.');
                return;
            }
             if (!selectedGroupId || selectedGroupId === 'all') {
                 // This check is slightly redundant now but safe
                 alert('Internal error: No group selected for post submission.');
                 return;
             }


            try {
                 // --- Use the NEW API endpoint ---
                const response = await fetch(`/api/groups/${selectedGroupId}/posts`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${authToken}`,
                    },
                    body: JSON.stringify({ title: title, content: content }),
                });

                if (!response.ok) {
                    let error = { message: `HTTP error! status: ${response.status}` };
                    try { error = await response.json(); } catch(e) {}
                    console.error('Error creating post:', error);
                    alert(error.error || error.message || 'Failed to create post.');
                    return;
                }

                // Success case
                const newPost = await response.json(); // API returns the new post
                console.log('Success creating post:', newPost);

                // --- Render the new post ---
                // Check if we are currently viewing the group where the post was made OR 'all'
                // This logic could be improved, maybe fetchPosts should handle adding the new post?
                // For now, just prepend if viewing that specific group.
                if (selectedGroupId === newPost.group._id) { // API returns populated group ID/Name
                     const postElement = renderPost(newPost, false); // Render, not showing group name here
                     if (postListContainer) postListContainer.prepend(postElement);
                     fetchAndRenderComments(newPost._id);
                } else {
                    // If viewing 'all' or another group, maybe just show a success message
                    // or fetchPosts again for the current view to include the new one if relevant.
                    // For simplicity now, just clear form.
                     alert(`Post created successfully in group '${newPost.group.name}'!`);
                }

                // Clear form
                titleInput.value = '';
                contentInput.value = '';

            } catch (error) {
                console.error('Network or other error creating post:', error);
                alert('Network error while creating post.');
            }
        });
    } // End if(postForm)


    // --- REGISTRATION FORM SUBMISSION ---
    if (registrationForm) {
        registrationForm.addEventListener('submit', async function(event) {
            // ... (existing registration code - seems okay) ...
             event.preventDefault();
            const usernameInput = document.getElementById('register-username');
            const passwordInput = document.getElementById('register-password');
            const username = usernameInput.value.trim();
            const password = passwordInput.value; // Don't trim password

            registrationMessage.textContent = '';
            registrationMessage.classList.remove('success', 'error', 'show'); // Reset classes

            if (!username || !password) {
                registrationMessage.textContent = 'Please enter a username and password.';
                registrationMessage.classList.add('error','show');
                return;
            }
             if (password.length < 6) {
                 registrationMessage.textContent = 'Password must be at least 6 characters.';
                 registrationMessage.classList.add('error','show');
                 return;
             }

            try {
                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', },
                    body: JSON.stringify({ username: username, password: password }),
                });
                const data = await response.json();
                if (response.ok) {
                    registrationMessage.textContent = data.message;
                    registrationMessage.classList.add('success','show');
                    console.log('Registration successful:', data);
                    usernameInput.value = '';
                    passwordInput.value = '';
                } else {
                    registrationMessage.textContent = data.error || `Registration failed (Status: ${response.status})`;
                    registrationMessage.classList.add('error','show');
                    console.error('Registration failed:', data);
                }
            } catch (error) {
                registrationMessage.textContent = 'Network error during registration.';
                registrationMessage.classList.add('error','show');
                console.error('Error during registration:', error);
            }
        });
    } // End if(registrationForm)


    // --- LOGIN FORM SUBMISSION ---
    if (loginForm) {
        loginForm.addEventListener('submit', async function(event) {
            // ... (existing login code - needs update to message display) ...
            event.preventDefault();
            const usernameInput = document.getElementById('login-username');
            const passwordInput = document.getElementById('login-password');
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            loginMessage.textContent = '';
            loginMessage.classList.remove('success', 'error', 'show'); // Reset classes

            if (!username || !password) {
                loginMessage.textContent = 'Please enter a username and password.';
                 loginMessage.classList.add('error', 'show');
                return;
            }

            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', },
                    body: JSON.stringify({ username: username, password: password }),
                });
                const data = await response.json();

                if (response.ok) {
                    loginMessage.textContent = data.message;
                    loginMessage.classList.add('success', 'show');
                    console.log('Login successful:', data);

                    localStorage.setItem('authToken', data.token);
                    localStorage.setItem('userId', data.userId);
                    localStorage.setItem('username', data.username);

                    usernameInput.value = '';
                    passwordInput.value = '';

                    // --- Maybe update UI state (e.g., hide login/register, show username) ---
                    // updateLoginState(); // Example function call

                    fetchPosts('all'); // Refresh post list (shows 'all' after login)

                } else {
                    loginMessage.textContent = data.error || `Login failed (Status: ${response.status})`;
                    loginMessage.classList.add('error', 'show');
                    console.error('Login failed:', data);
                }

            } catch (error) {
                loginMessage.textContent = 'Network error during login.';
                loginMessage.classList.add('error', 'show');
                console.error('Error during login:', error);
            }
        });
    } // End if(loginForm)


     // --- Initial Setup Calls ---
     fetchAndRenderGroups(); // Fetch groups when page loads
     fetchPosts('all');    // Fetch initial posts for 'all' feed


}); // --- END DOMContentLoaded ---


// ==========================================================
// updateVote function (Should be outside DOMContentLoaded)
// ==========================================================
async function updateVote(postId, action) {
    const token = localStorage.getItem('authToken');

    if (!token) {
        console.error('No auth token found for voting. Please log in.');
        alert('You must be logged in to vote.');
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}/${action}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            let error = { message: `HTTP error! status: ${response.status}` };
            try { error = await response.json(); } catch (e) {}
            console.error(`Error updating vote (${action}):`, error);
            alert(`Failed to ${action}: ${error.error || error.message || 'Unknown server error'}`);
            return;
        }

        const updatedPost = await response.json();
        console.log('Vote successful:', updatedPost);
        // Update UI
        const voteCountSpan = document.querySelector(`.vote-count[data-post-id="${postId}"]`);
        if (voteCountSpan) {
            voteCountSpan.textContent = updatedPost.votes;
        }
    } catch (error) {
        console.error(`Network or other error updating vote (${action}):`, error);
        alert(`Failed to ${action}. Please check your connection or try again later.`);
    }
}