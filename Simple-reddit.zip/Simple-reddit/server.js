// server.js (Corrected: Duplicate routes removed, 404 handler moved, GET /api/groups added)
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

console.log('--- server.js execution STARTED ---');

const app = express();
const port = 3000; // Ensure this is the correct port your backend should run on

// --- Core Middleware ---
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Parse JSON request bodies
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files from 'public' directory

// --- MongoDB Connection ---
// Make sure your MongoDB server is running locally on the default port 27017
mongoose.connect('mongodb://127.0.0.1:27017/simple-reddit', {
    // useNewUrlParser and useUnifiedTopology are deprecated but harmless for now
    // Consider removing them if using Mongoose 6+
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => {
    console.error('Could not connect to MongoDB:', err);
    process.exit(1); // Exit if DB connection fails
});

// --- Mongoose Model Definitions ---

// User Model
const User = mongoose.model('User', new mongoose.Schema({
    username: { type: String, required: true, unique: true, minlength: 3, maxlength: 30, trim: true },
    password: { type: String, required: true }, // Length validation done during registration
    createdAt: { type: Date, default: Date.now }
}));

// Group Model
const GroupSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true, trim: true },
    description: { type: String, required: true, trim: true },
    createdAt: { type: Date, default: Date.now }
});
const Group = mongoose.model('Group', GroupSchema);

// Post Model
const PostSchema = new mongoose.Schema({
    title: { type: String, required: true, minlength: 1, maxlength: 200, trim: true },
    content: { type: String, required: true, minlength: 1, trim: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group', required: true },
    createdAt: { type: Date, default: Date.now },
    votes: { type: Number, default: 0 }
});
const Post = mongoose.model('Post', PostSchema);

// Comment Model
const CommentSchema = new mongoose.Schema({
    text: { type: String, required: true, minlength: 1, trim: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // Assuming comments must have authors
    post: { type: mongoose.Schema.Types.ObjectId, ref: 'Post', required: true },
    createdAt: { type: Date, default: Date.now }
});
const Comment = mongoose.model('Comment', CommentSchema);

// --- Authentication Middleware ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Format: Bearer <TOKEN>

    if (token == null) {
        // No token provided
        return res.status(401).json({ error: 'Unauthorized: No token provided' });
    }

    // IMPORTANT: Use an environment variable for your secret key in production!
    const secretKey = 'your-secret-key'; // Replace with a strong secret or env variable

    jwt.verify(token, secretKey, (err, user) => {
        if (err) {
            console.error('JWT Verification Error:', err.message); // Log specific error
            // Differentiate between expired and invalid tokens if needed
            if (err.name === 'TokenExpiredError') {
                return res.status(403).json({ error: 'Forbidden: Token expired' });
            }
            return res.status(403).json({ error: 'Forbidden: Invalid token' });
        }
        // Attach user payload (e.g., { userId: '...', username: '...' }) to the request object
        req.user = user;
        next(); // Proceed to the protected route
    });
};

// --- API Route Definitions ---

// User Registration
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }
    if (password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    if (username.length < 3) {
        return res.status(400).json({ error: 'Username must be at least 3 characters' });
    }

    try {
        const existingUser = await User.findOne({ username: username.trim() });
        if (existingUser) {
            return res.status(409).json({ error: 'Username already exists' }); // 409 Conflict
        }

        const hashedPassword = await bcrypt.hash(password, 10); // Salt rounds = 10
        const newUser = new User({ username: username.trim(), password: hashedPassword });
        const savedUser = await newUser.save();

        // Send back limited user info (never the password hash)
        res.status(201).json({
            message: 'User registered successfully',
            userId: savedUser._id,
            username: savedUser.username
        });
    } catch (err) {
        console.error('Error registering user:', err);
        res.status(500).json({ error: 'Server error during registration' });
    }
});

// User Login
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    try {
        const user = await User.findOne({ username: username.trim() });
        if (!user) {
            // Generic message for security (don't reveal if username exists)
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            // Generic message
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Generate JWT
        const payload = { userId: user._id, username: user.username };
        const secretKey = 'your-secret-key'; // Use the same secret as in authenticateToken
        const token = jwt.sign(payload, secretKey, { expiresIn: '1h' }); // Token expires in 1 hour

        res.status(200).json({
            message: 'Login successful',
            token: token,
            userId: user._id,
            username: user.username
        });

    } catch (err) {
        console.error('Error during login:', err);
        res.status(500).json({ error: 'Server error during login' });
    }
});


// ⬇️⬇️⬇️ ===== START: Added Route Handler ===== ⬇️⬇️⬇️
// GET all groups
app.get('/api/groups', async (req, res) => {
    console.log('GET /api/groups called'); // Log when this route is hit
    try {
        // Fetch all documents from the 'groups' collection, sort by name ascending
        const groups = await Group.find().sort({ name: 1 });
        res.json(groups); // Send the list of groups back as JSON
    } catch (error) {
        console.error("Error fetching groups:", error); // Log any error during DB query
        res.status(500).json({ message: "Failed to fetch groups", error: error.message }); // Send a 500 status on error
    }
});
// ⬆️⬆️⬆️ ===== END: Added Route Handler ===== ⬆️⬆️⬆️


// Get All Posts (for the 'All Posts' feed)
app.get('/api/posts', async (req, res) => {
    console.log('GET /api/posts called');
    try {
        const posts = await Post.find()
            .populate('author', 'username') // Get author's username
            .populate('group', 'name')      // Get group's name
            .sort({ createdAt: 'desc' });   // Newest first
        res.json(posts);
    } catch (err) {
        console.error('Error fetching all posts:', err);
        res.status(500).json({ error: 'Failed to fetch posts' });
    }
});

// Get Posts for a Specific Group
app.get('/api/groups/:groupId/posts', async (req, res) => {
    const { groupId } = req.params;
    console.log(`GET /api/groups/${groupId}/posts called`);

    if (!mongoose.Types.ObjectId.isValid(groupId)) {
        return res.status(400).json({ error: 'Invalid group ID format' });
    }

    try {
        // Verify group exists (optional, but good practice)
        const groupExists = await Group.findById(groupId);
        if (!groupExists) {
             return res.status(404).json({ error: 'Group not found' });
        }

        const posts = await Post.find({ group: groupId })
            .populate('author', 'username') // Get author's username
          // No need to populate group name here, we know the group ID
            .sort({ createdAt: 'desc' });   // Newest first

        res.json(posts);
    } catch (err) {
        console.error(`Error fetching posts for group ${groupId}:`, err);
        res.status(500).json({ error: 'Failed to fetch posts for the group' });
    }
});

// Create a Post in a Specific Group (Protected)
app.post('/api/groups/:groupId/posts', authenticateToken, async (req, res) => {
    const { groupId } = req.params;
    const { title, content } = req.body;
    const authorId = req.user.userId; // Extracted from validated token

    console.log(`POST /api/groups/${groupId}/posts called by user ${authorId}`);

    if (!mongoose.Types.ObjectId.isValid(groupId)) {
        return res.status(400).json({ error: 'Invalid group ID format' });
    }
    if (!title || title.trim().length === 0 || !content || content.trim().length === 0) {
        return res.status(400).json({ error: 'Title and content are required and cannot be empty' });
    }

    try {
        // Check if the group exists before creating post
        const groupExists = await Group.findById(groupId);
        if (!groupExists) {
            return res.status(404).json({ error: 'Group not found' });
        }

        const newPost = new Post({
            title: title.trim(),
            content: content.trim(),
            author: authorId,
            group: groupId // Link post to the specified group
        });

        const savedPost = await newPost.save();

        // Populate author and group details for the response
        const populatedPost = await savedPost.populate([
            { path: 'author', select: 'username' },
            { path: 'group', select: 'name' }
        ]);

        res.status(201).json(populatedPost); // Send back the newly created and populated post

    } catch (err) {
        console.error(`Error creating post in group ${groupId}:`, err);
        res.status(500).json({ error: 'Failed to create post' });
    }
});

// Get Comments for a Specific Post
app.get('/api/posts/:postId/comments', async (req, res) => {
    const { postId } = req.params;
    console.log(`GET /api/posts/${postId}/comments called`);

    if (!mongoose.Types.ObjectId.isValid(postId)) {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }

    try {
        // Check if post exists first
        const postExists = await Post.findById(postId);
        if (!postExists) {
             return res.status(404).json({ error: 'Post not found' });
        }

        const comments = await Comment.find({ post: postId })
            .populate('author', 'username') // Populate author's username
            .sort({ createdAt: 'asc' });    // Oldest comments first

        res.json(comments);
    } catch (err) {
        console.error(`Error fetching comments for post ${postId}:`, err);
        res.status(500).json({ error: 'Failed to fetch comments' });
    }
});

// Add a Comment to a Post (Protected)
app.post('/api/posts/:postId/comments', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const { text } = req.body;
    const authorId = req.user.userId;
    console.log(`POST /api/posts/${postId}/comments called by user ${authorId}`);


    if (!mongoose.Types.ObjectId.isValid(postId)) {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }
    if (!text || text.trim().length === 0) {
        return res.status(400).json({ error: 'Comment text cannot be empty' });
    }

    try {
        // Check if the post exists before allowing comment
        const postExists = await Post.findById(postId);
        if (!postExists) {
            return res.status(404).json({ error: 'Post not found' });
        }

        const newComment = new Comment({
            text: text.trim(),
            author: authorId,
            post: postId
        });
        const savedComment = await newComment.save();

        // Populate author info for the response
        const populatedComment = await savedComment.populate('author', 'username');
        res.status(201).json(populatedComment); // Send back the new comment
    } catch (err) {
        console.error(`Error adding comment to post ${postId}:`, err);
        res.status(500).json({ error: 'Failed to add comment' });
    }
});

// Upvote a Post (Protected)
app.post('/api/posts/:postId/upvote', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const userId = req.user.userId; // Useful for logging or more complex voting logic later
    console.log(`POST /api/posts/${postId}/upvote called by user ${userId}`);

    if (!mongoose.Types.ObjectId.isValid(postId)) {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }

    try {
        // Find the post and increment its votes by 1
        // { new: true } ensures the updated document is returned
        const updatedPost = await Post.findByIdAndUpdate(
            postId,
            { $inc: { votes: 1 } },
            { new: true }
        ).select('votes'); // Optionally select only the votes field if that's all needed

        if (!updatedPost) {
            return res.status(404).json({ error: 'Post not found' });
        }
        // Send back the updated vote count (or the whole post if needed)
        res.json({ _id: postId, votes: updatedPost.votes });

    } catch (err) {
        console.error(`Error upvoting post ${postId}:`, err);
        res.status(500).json({ error: 'Failed to upvote post' });
    }
});

// Downvote a Post (Protected)
app.post('/api/posts/:postId/downvote', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const userId = req.user.userId;
    console.log(`POST /api/posts/${postId}/downvote called by user ${userId}`);


    if (!mongoose.Types.ObjectId.isValid(postId)) {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }

    try {
        // Find the post and decrement its votes by 1
        const updatedPost = await Post.findByIdAndUpdate(
            postId,
            { $inc: { votes: -1 } }, // Decrement votes
            { new: true }
        ).select('votes');

        if (!updatedPost) {
            return res.status(404).json({ error: 'Post not found' });
        }
        res.json({ _id: postId, votes: updatedPost.votes });

    } catch (err) {
        console.error(`Error downvoting post ${postId}:`, err);
        res.status(500).json({ error: 'Failed to downvote post' });
    }
});


// --- Catch-All 404 Handler (Should be after all other routes) ---
app.use((req, res, next) => {
    res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
});

// --- Generic Error Handler (Optional but recommended) ---
// This catches errors passed via next(err) from async routes or sync errors
app.use((err, req, res, next) => {
    console.error("Unhandled Error:", err.stack || err); // Log the full error stack
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error'
    });
});

console.log('--- server.js execution reached BEFORE app.listen ---');

// --- Start the Server ---
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});