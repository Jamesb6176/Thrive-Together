// filepath: /Users/jamesball/Desktop/Simple-reddit/scripts/seed.js
const mongoose = require('mongoose');
const Group = require('../models/Group'); // Adjust the path to your Group model

mongoose.connect('mongodb://127.0.0.1:27017/simple-reddit', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(async () => {
    console.log('Connected to MongoDB');

    // Clear existing groups (optional)
    await Group.deleteMany({});

    // Insert test data
    await Group.insertMany([
        { name: "Test Group 1", description: "This is a test group" },
        { name: "Test Group 2", description: "Another test group" }
    ]);

    console.log('Test data inserted');
    mongoose.connection.close();
})
.catch(err => {
    console.error('Error connecting to MongoDB:', err);
});